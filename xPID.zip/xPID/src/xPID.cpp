
#include "xPID.h"


void xPID::SetTerms(double Kp, double Ki, double Kd) {
		_Kp = Kp;
		_Ki = Ki;
		_Kd = Kd;
	}

	void xPID::SetWindup(const int MAX, const int MIN) {
		_MAX = MAX;
		_MIN = MIN;
	}

	void xPID::SetSampleTime(unsigned int sampleTime) {

		_sampleTime = sampleTime;
		double k = sampleTime/_sampleTime;
		_Ki = _Ki * k;
		_Kd = _Kd * k;

	}
	
	
	void xPID::CalcPID(double *const input, double * const
		setPoint, double *const PID)
	{

		unsigned long lastTime = 0.0;
		double error, lastError,lastInput;
		double epsilon = 0.05;// error treshold variable
		double I = 0.0;//integral variable
		double D;// derivative variable

		error = *setPoint - *input;

		if ((millis() - lastTime) >= _sampleTime) { // run PID if time is @ sample time
			if (fabs(error) > epsilon) {// if the error is too small stop integration
				I += (error+lastError)/2.0; // trapezoidal rule for integration
			}// end if epsilon

			D = (*input - lastInput); // calculate slope of input

			*PID = _Kp * error + _Ki * I + _Kd * D; // PID output variable

			if (*PID > _MAX) *PID = _MAX;//windup guard output
			if (*PID < _MIN) *PID = _MIN;

			lastError = error; // save for next time
			lastInput = *input;
			lastTime = millis();
		}// end if (timechange > sampletime)
	
	}

