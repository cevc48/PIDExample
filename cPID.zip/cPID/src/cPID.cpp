#include "cPID.h"

void cPID::SetGains(float _Kp, float _Ki, float _Kd) {
	Kp = _Kp;
	Ki = _Ki;
	Kd = _Kd;
}

void cPID::SetWindupGuard(float _Wg1, float _Wg2) {
	Wg1 = _Wg1;
	Wg2 = _Wg2;
}

void cPID::SetSampleTime(unsigned int nst) {
	sampleTime = nst;
}

void cPID::ChangeSampleTime(unsigned int nst) {
	float r = ((float)nst / (float)sampleTime);

	Ki *= r;
	Kd /= r;
	sampleTime = nst;
}

int cPID::GetSampleTime() const {
	return sampleTime;
}

float cPID::GetKp() const {
	return Kp;
}

float cPID::GetKi() const {
	return Ki;
}

float cPID::GetKd() const {
	return Kd;
}

float cPID::GetWg1()const {
	return Wg1;
}

float cPID::GetWg2()const {
	return Wg2;
}

void cPID::Compute(float *const pid, float * const input, float * const setpoint) { // calculate PID
	float deltaT = millis() - lastTime; // deltaT = actual time - time after computation
	if (deltaT >= sampleTime) { // if deltaT is equal to sample time do processing
		error = *setpoint - *input;

		if (abs(error) > epsilon) { // if the the error is too small stop integration
			integral += error;// rectangular integration
		}// end if

		derivative = (*input - lastInput);

		P = Kp * error; // proportional component
		I = Ki * integral; // integral component
		D = Kd * derivative; // derivative component

		if (I > Wg1) I = Wg1; // integral windup guard 
		if (I < Wg2)  I = Wg2;

		*pid = P + I + D; //output PID value

		if (*pid > Wg1)(*pid) = Wg1; //output windup guard 
		if (*pid < Wg2)(*pid) = Wg2;

		lastInput = *input;		//update input
		lastTime = millis();	//update time

# if defined PRINT
		Serial.print(*setpoint);
		Serial.print(",");
		Serial.print(*input);
		Serial.print(",");
		Serial.println(*pid);
#endif
	}// end if
}// end Compute();