
#include "xPID.h"


void xPID::SetTerms(float Kp, float Ki, float Kd) {
		_Kp = Kp;
		_Ki = Ki;
		_Kd = Kd;
	}

	void xPID::SetWindup(const int MAX, const int MIN) {
		_MAX = MAX;
		_MIN = MIN;
	}

	void xPID::SetSampleTime(unsigned int sampleTime) {

		_sampleTime = sampleTime;

	}
	
	
	void xPID::CalcPID(float &input, float &setPoint, float  &PID)
	{

		unsigned long lastTime = 0.0;
		float error, lastError;
		float epsilon = 0.05;// error treshold variable
		float I = 0.0;//integral variable
		float D;// derivative variable

		error = abs(setPoint - input);
		 

		if ((millis() - lastTime) >= _sampleTime) { // run PID if time is @ sample time
			if (abs(error) > epsilon) {// if the error is too small stop integration
				I += error; // add current error to the running total
			}// end if epsilon

			D = (error - lastError); // calculate slope of input

			PID = _Kp * error + _Ki * I + _Kd * D; // output variable

			if (PID > _MAX) PID = _MAX;//windup guard output
			if (PID < _MIN) PID = _MIN;

			lastError = error; // save for next time
			lastTime = millis();
		}// end if (timechange > sampletime)
	
	}

